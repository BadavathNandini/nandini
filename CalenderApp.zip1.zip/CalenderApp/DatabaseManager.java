public static void initializeDB() {
    try {
        Class.forName("org.sqlite.JDBC"); // Load the SQLite driver
        
        Connection conn = DriverManager.getConnection("jdbc:sqlite:calendar.db");
        
        String sql = "CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, title TEXT, date TEXT, description TEXT)";
        conn.createStatement().execute(sql);
        
        conn.close();
    } catch (ClassNotFoundException e) {
        e.printStackTrace(); // If the driver isn't found
    } catch (SQLException e) {
        e.printStackTrace(); // If there is a database error
    }
}
