import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class DatabaseManager {
    private static final String URL = "jdbc:sqlite:calendar.db";

    // Initialize database & table
    public static void initializeDB() {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, title TEXT, date TEXT, description TEXT)";
            conn.createStatement().execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Save event to database
    public static void saveEvent(Event event) {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "INSERT INTO events (title, date, description) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, event.getTitle());
            stmt.setString(2, event.getDate().toString());
            stmt.setString(3, event.getDescription());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve and display all events
    public static void displayEvents() {
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "SELECT * FROM events";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                System.out.println("Event: " + rs.getString("title") + " on " + rs.getString("date"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("-----------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}