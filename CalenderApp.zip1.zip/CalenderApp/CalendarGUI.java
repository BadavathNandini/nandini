import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;

public class CalendarGUI {
    public CalendarGUI() {
        DatabaseManager.initializeDB();

        JFrame frame = new JFrame("Calendar App");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel titleLabel = new JLabel("Event Title:");
        JTextField titleField = new JTextField(15);

        JLabel dateLabel = new JLabel("Event Date:");
        JDateChooser dateChooser = new JDateChooser();

        JLabel descLabel = new JLabel("Description:");
        JTextField descField = new JTextField(20);

        JButton addEventButton = new JButton("Add Event");
        JButton viewEventsButton = new JButton("View Events");

        addEventButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText();
                String description = descField.getText();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String date = sdf.format(dateChooser.getDate());

                if (!title.isEmpty() && !description.isEmpty() && dateChooser.getDate() != null) {
                    DatabaseManager.saveEvent(title, date, description);
                    titleField.setText("");
                    descField.setText("");
                    dateChooser.setDate(null);
                    JOptionPane.showMessageDialog(frame, "Event Added!");
                } else {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields!");
                }
            }
        });

        viewEventsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String events = DatabaseManager.getEvents();
                if (events.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "No events saved yet!");
                } else {
                    JOptionPane.showMessageDialog(frame, events);
                }
            }
        });

        frame.add(titleLabel);
        frame.add(titleField);
        frame.add(dateLabel);
        frame.add(dateChooser);
        frame.add(descLabel);
        frame.add(descField);
        frame.add(addEventButton);
        frame.add(viewEventsButton);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new CalendarGUI(); 
    }
}