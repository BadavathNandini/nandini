import java.time.LocalDate;
import java.util.Scanner;

public class CalendarApp {
    public static void main(String[] args) {
        DatabaseManager.initializeDB();  // Create database table
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Welcome to the Calendar Program!");

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add Event");
            System.out.println("2. View Events");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            if (choice == 1) {
                System.out.print("Enter event title: ");
                String title = scanner.nextLine();

                System.out.print("Enter event date (YYYY-MM-DD): ");
                LocalDate date = LocalDate.parse(scanner.nextLine());

                System.out.print("Enter event description: ");
                String description = scanner.nextLine();

                DatabaseManager.saveEvent(new Event(title, date, description));
                System.out.println("Event added successfully!");
            } 
            else if (choice == 2) {
                System.out.println("All Saved Events:");
                DatabaseManager.displayEvents();
            } 
            else if (choice == 3) {
                System.out.println("Goodbye!");
                break;
            } 
            else {
                System.out.println("Invalid option, please try again.");
            }
        }

        scanner.close();
    }
}